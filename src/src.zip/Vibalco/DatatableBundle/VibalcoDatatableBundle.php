<?php

namespace Vibalco\DatatableBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VibalcoDatatableBundle extends Bundle
{
}
