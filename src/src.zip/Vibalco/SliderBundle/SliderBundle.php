<?php

namespace Vibalco\SliderBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SliderBundle extends Bundle
{
}
