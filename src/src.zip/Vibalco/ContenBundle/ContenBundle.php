<?php

namespace Vibalco\ContenBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ContenBundle extends Bundle
{
}
