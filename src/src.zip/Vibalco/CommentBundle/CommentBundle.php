<?php

namespace Vibalco\CommentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommentBundle extends Bundle
{
}
