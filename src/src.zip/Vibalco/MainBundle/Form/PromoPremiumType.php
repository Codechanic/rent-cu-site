<?php

namespace Vibalco\MainBundle\Form;

use Symfony\Component\Form\FormBuilderInterface;

class PromoPremiumType extends PromoType
{
}
