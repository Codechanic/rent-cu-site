<?php

namespace Vibalco\MainBundle\Model;

/**
 *
 * @author viko
 */
interface CodeInterface {

    public function code();
}
