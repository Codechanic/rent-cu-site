<?php

namespace Vibalco\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Promo
 * 
 * @ORM\Entity
 */
class PromoStrip extends Promo {
}