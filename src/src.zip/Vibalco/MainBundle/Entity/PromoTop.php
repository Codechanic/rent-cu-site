<?php

namespace Vibalco\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * PromoTop
 *
 * @ORM\Entity
 */
class PromoTop extends Promo {
}