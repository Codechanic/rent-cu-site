<?php

namespace Vibalco\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Promo
 * 
 * @ORM\Entity
 * 
 */
class PromoPremium extends Promo 
{
}