<?php

namespace Vibalco\GalleryBundle\Model;

interface GalleryInterface {

    public function galleryOwner();
}

?>
