<?php

namespace Vibalco\GalleryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GalleryBundle extends Bundle
{
}
